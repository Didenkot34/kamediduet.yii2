<?php

namespace app\modules\event;

class Module extends \yii\base\Module
{
    public $controllerNamespace = 'app\modules\event\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
