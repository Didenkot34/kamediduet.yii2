jQuery(document).ready(function() {
 $('#uploadform-imagefile').addClass('btn btn-success');
 
// $('div.postsmy').each(function(){
//     $(this).hover(function(){
//          $(this).addClass('slideInRightMy');
//     });
//    
// });
});


    