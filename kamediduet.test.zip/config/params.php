<?php

return [
    'adminEmail' => 'didenkot34@gmail.com',
];
