<?php
use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
/* @var $this yii\web\View */

$this->title = $post->title;
?>
<div class="site-index">
    <div class=" breadcrumb">
        <?= Html::a('Главная', ['/']) ?>/<?= Html::a($category->title, ['user/posts','id'=>$post->id_categories]) ?>/<?=$post->title?>
    </div>
    <!-- Content Row -->
        <div class="row">

            <!-- Blog Post Content Column -->
            <div class="col-lg-8">

                <!-- Blog Post -->

                <hr>

                <!-- Date/Time -->
                <?= Html::tag('h1', Html::encode($post->title), ['class' => 'category_title text-center']) ?>

                <hr>

                <!-- Preview Image -->
                <img class="img-responsive pulseMy" src="http://placehold.it/900x300" alt="">

                <hr>

                <!-- Post Content -->
                <?= Html::tag('p', $post->discription, ['class' => 'lead'])?>
                <hr>

                <!-- Blog Comments -->

                <!-- Comments Form -->
        
        
              <div class="well">
                    <h4>Оставить отзыв <i class="fa fa-thumbs-o-up fa-2x"></i> :</h4>
               <?php $form = ActiveForm::begin([
                   'id' => 'form-comment',
                   'action' => ['user/save-comment'],
                   
                   ]); ?>

                <?= $form->field($comment, 'id_posts')->hiddenInput(['value'=>$post->id_posts])->label(FALSE) ?>
                <?= $form->field($comment, 'users_name')->label('Ваше Имя') ?>
                <?= $form->field($comment, 'users_last_name')->label('Ваша Фамилия') ?>
                <?= $form->field($comment, 'users_email')->label('Ваш email') ?>

                
   
                <?= $form->field($comment, 'comments')->textarea(['class'=>'form-control','rows'=>3]) ?>

                <div class="form-group">
                    <?= Html::submitButton('Оставить отзыв', ['class' => 'btn btn-primary', 'name' => 'saveComment-button']) ?>
                </div>

            <?php ActiveForm::end(); ?>
                </div>

                <hr>

                <!-- Posted Comments -->

                <!-- Comment -->
                 <?php foreach ($saved_comments as $saved_comment): ?>
                <div class="media">
                    <a class="pull-left" href="#">
                        <img class="media-object" src="http://placehold.it/64x64" alt="">
                    </a>
                    <div class="media-body">
                        <h4 class="media-heading"><?=$saved_comment->users_name.' '.$saved_comment->users_last_name?>
                            <small><?=$saved_comment->created_at?></small>
                        </h4>
                        <?=$saved_comment->comments?>
                    </div>
                </div>
                 <?php endforeach;?>
            </div>

            <!-- Blog Sidebar Widgets Column -->
            <div class="col-md-4">

                <!-- Blog Search Well -->
                <div class="well">
                    <h4>Blog Search</h4>
                    <div class="input-group">
                        <input type="text" class="form-control">
                        <span class="input-group-btn">
                            <button class="btn btn-default" type="button"><i class="fa fa-search"></i></button>
                        </span>
                    </div>
                    <!-- /.input-group -->
                </div>

                <!-- Blog Categories Well -->
                <div class="well">
                    <h4 class="text-center">Blog Categories</h4>
                    <div class="row">
                        <div class="col-lg-12 ">
                            
                                  <?php foreach ($categories as $single_category): ?>
                            <ul class="nav nav-pills">
                                <li class="active text-center shakeMy">
                                    <?= Html::a($single_category->title.'<span class="badge">6</span>', ['user/posts','id'=>$single_category->id_categories]) ?>
                                </li>
                                <li class="active text-center shakeMy pull-right">
                                    <?= Html::a('comments'.'<span class="badge">6</span>', ['user/posts','id'=>$single_category->id_categories]) ?>
                                </li>
                            </ul>
                            <br>
                                <?php endforeach;?>
                            
                        </div>
                        
                    </div>
                    <!-- /.row -->
                </div>

                <!-- Side Widget Well -->
                <div class="well">
                    <h4>Side Widget Well</h4>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore, perspiciatis adipisci accusamus laudantium odit aliquam repellat tempore quos aspernatur vero.</p>
                </div>

            </div>

        </div>
   <div class="body-content">

        <div class="row">
            <?php foreach ($posts as $single_post): ?>
            <div class="col-lg-4">
               
                <?= Html::tag('h2', $single_post->title, ['class' => 'post_title']) ?>

                <?= Html::tag('p', $single_post->short_discription, ['class' => 'post_discription'])?>

                <p><?= Html::a('More...', ['user/post','id'=>$single_post->id_posts], ['class' => 'btn btn-lg btn-success']) ?></p>
            </div>
            <?php endforeach;?>
        </div>

    </div>
</div>