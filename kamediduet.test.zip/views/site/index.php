<?php
use yii\helpers\Html;
/* @var $this yii\web\View */

$this->title = 'Жюль и Верн';
?>
<div class="slides " style="width: 90% ;   margin-bottom: 0px;">
                <ul> <!-- Слайды -->
                    <li> <?= Html::img('@web/uploads/karassik@yandex.ru/106.jpg',[''=>'100%']); ?>
                        <div class=" col-lg-12">Описание #1</div>
                    </li>
                    <li> <?= Html::img('@web/uploads/karassik@yandex.ru/101.jpg',['height'=>'100%']); ?>
                        <div class=" text-center col-lg-12"><a>Анастаия и Роман</a></div>
                    </li>
                    <li> <?= Html::img('@web/uploads/karassik@yandex.ru/106.jpg',['height'=>'100%']); ?>
                        <div class=" col-lg-12"> Описание #3</div>
                    </li>
                    <li> <?= Html::img('@web/uploads/karassik@yandex.ru/101.jpg',['height'=>'100%']); ?>
                        <div col-lg-12>Описание #4</div>
                    </li>
                </ul>
</div>
