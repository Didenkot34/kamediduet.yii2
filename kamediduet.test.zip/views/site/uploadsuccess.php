<?php
use yii\helpers\Html;
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<h1>Ваш файл успешно загружен</h1>

<?= Html::img('@web/uploads/'.Yii::$app->user->identity->email.'/'.$model->imageFile->baseName . '.'.$model->imageFile->extension, ['alt' => $model->imageFile->baseName,'class' => 'img-circle' ]) ?>