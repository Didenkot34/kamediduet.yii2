<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<?php
use yii\widgets\ActiveForm;
use yii\helpers\Html;
?>

<?php $form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data']]) ?>

    <?= $form->field($model, 'imageFile')->fileInput() ?>

<button class=" btn btn-primary">Submit</button>

<?php ActiveForm::end() ?>

<div class="container">
    <div class="slides">
        <ul> <!-- Слайды -->
            <li> <?= Html::img('@web/uploads/karassik@yandex.ru/106.jpg'); ?>
                <div>Описание #1</div>
            </li>
            <li> <?= Html::img('@web/uploads/karassik@yandex.ru/101.jpg'); ?>
                <div>Описание #2</div>
            </li>
            <li> <?= Html::img('@web/uploads/karassik@yandex.ru/106.jpg'); ?>
                <div>Описание #3</div>
            </li>
            <li> <?= Html::img('@web/uploads/karassik@yandex.ru/101.jpg'); ?>
                <div>Описание #4</div>
            </li>
        </ul>
    </div>
</div>
