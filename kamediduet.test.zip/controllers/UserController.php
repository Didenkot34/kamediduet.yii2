<?php
namespace app\controllers;
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
use Yii;


use yii\web\Controller;
use app\models\Categories;
use app\models\Posts;
use app\models\Comments;
use app\models\SaveComment;



class UserController extends Controller
{
   
   
    public function actionPosts($id)
    {
        $category = Categories::find()
                    ->where(['id_categories' => $id])
                    ->one();
        $posts    = Posts::find()
                    ->where(['id_categories' => $id])
                    ->orderBy('id_posts')
                    ->all();
        return $this->render('posts', [
            'posts'    => $posts,
            'category' => $category,
        ]);
    }
    public function actionSinglePost($id)
    {
        $post     = Posts::find()
                    ->where(['id_posts' => $id])
                    ->one();
        $category = Categories::find()
                    ->where(['id_categories' => $post->id_categories])
                    ->one();
        $posts    = Posts::find()
                    ->where(['id_categories' => $post->id_categories])
                    ->andWhere(['!=', 'id_posts', $id])
                    ->orderBy('id_posts')
                    ->all();
        $categories = Categories::find()
                ->all();
        $saved_comments = Comments::find()
                ->where(['id_posts' => $id])
                 ->all();
         $comment = new SaveComment();
        return $this->render('single-post', [
            'post'     => $post,
            'posts'     => $posts,
            'category' => $category,
            'categories' => $categories,
            'comment' => $comment,
            'saved_comments' => $saved_comments,
        ]);
    }
    public function actionSaveComment()
    {
        
        $comment = new SaveComment();
        if ($comment->load(Yii::$app->request->post())) {
            if ($comment->saveComment()) {
                $this->redirect('single-post?id='.$comment->id_posts);
//               return $this->render('single-post', [
//            'comment' => $comment,
//            'saved_comments' => $saved_comments,
//             ]);
            }
        }
    }
    
}